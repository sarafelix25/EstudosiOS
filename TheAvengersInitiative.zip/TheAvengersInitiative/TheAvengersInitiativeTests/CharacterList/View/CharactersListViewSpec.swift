//
//  CharactersListViewSpec.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 02/09/21.
//

import Foundation
import Quick
import Nimble_Snapshots
import Nimble

@testable import TheAvengersInitiative

final class CharactersListViewSpec: QuickSpec{
	override func spec() {
		
		var viewModel: CharacterListViewModel!
		var sut: CharactersListView!
		var apiMock: CharactersApiMock!
		
		describe("CharactersListView"){
			context("when view is initialized"){
				
				beforeEach {
					apiMock = .init()
					viewModel = .init(api: apiMock)
					sut = .init(viewModel: viewModel, delegate: nil)
					sut.frame = UIScreen.main.bounds
				}
				
				it("should have expected layout"){
					expect(sut) == snapshot("CharacterList_view!")
				}
			}
		}
	}
}
