//
//  CharacterAPIMock.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 30/08/21.
//

import Foundation

@testable import TheAvengersInitiative

final class CharactersApiMock: CharactersAPIProtocol {
	var shouldSucceed: Bool = true
	
	func getCharacters(offset: Int, completion: @escaping ((Result<CharactersListWrapper>) -> Void)) {
		if shouldSucceed {
			completion(.success(CharactersListWrapper.stub()))
		} else {
			completion(.error(APIError.generic))
		}
	}
}
