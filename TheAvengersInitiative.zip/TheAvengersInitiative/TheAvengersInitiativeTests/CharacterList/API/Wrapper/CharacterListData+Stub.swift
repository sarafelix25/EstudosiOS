//
//  CharacterListData+Stub.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 30/08/21.
//

import Foundation

@testable import TheAvengersInitiative

extension CharacterListData {
	static func stub(offset: Int = 10, limit: Int = 10, total: Int = 10, count: Int = 10, results: [Character] = Character.stub(count: 10)) -> CharacterListData {
		let characterListDataStub: CharacterListData = .init(offset: offset, limit: limit, total: total, count: total, results: results)
		return characterListDataStub
	}
}
