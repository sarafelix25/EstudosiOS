//
//  CharactersListWrapper+Stub.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 30/08/21.
//

import Foundation

@testable import TheAvengersInitiative

extension CharactersListWrapper {
	static func stub() -> CharactersListWrapper {
		let charactersListWrapperStub: CharactersListWrapper = .init(data: CharacterListData.stub())
		return charactersListWrapperStub
 	}
}
