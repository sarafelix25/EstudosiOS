//
//  CharacterAPISpy.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 24/08/21.
//

import Foundation

@testable import TheAvengersInitiative

final class CharactersAPISpy: CharactersAPIProtocol {
	var didCallGetCharacters: Bool = false

	func getCharacters(offset: Int, completion: @escaping ((_ result: Result<CharactersListWrapper>) -> Void)) {

		didCallGetCharacters = true

	}

}
