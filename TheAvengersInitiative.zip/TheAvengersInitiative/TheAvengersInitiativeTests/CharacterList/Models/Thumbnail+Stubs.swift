//
//  Thumbnail+Stubs.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 25/08/21.
//

import Foundation

@testable import TheAvengersInitiative

extension Character.Thumbnail {
	static func stub() -> Character.Thumbnail {
		let thumbnail: Character.Thumbnail = .init(path: URL(string: "https://www.google.com.br/")!, thumbExtension: "PNG")
		return thumbnail
	}
}
