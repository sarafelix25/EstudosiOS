//
//  Character+Stubs.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 25/08/21.
//

import Foundation

@testable import TheAvengersInitiative

extension Character {
	
	static func stub(id: Int = 1, name: String = "Iron Man", description: String = "descricao", thumbnail: Thumbnail = Character.Thumbnail.stub(), comicList: ComicList = ComicList.stub() ) -> Character {
		let character: Character = .init(id: id, name: name, description: description, thumbnail: thumbnail,
comicList: comicList)
		
		return character
	}
	
	
	static func stub(count: Int) -> [Character] {
		var characteres: [Character] = []

		
		for _ in 0 ..< count {
			characteres.append(stub())
		}
		 return characteres
	}
}
