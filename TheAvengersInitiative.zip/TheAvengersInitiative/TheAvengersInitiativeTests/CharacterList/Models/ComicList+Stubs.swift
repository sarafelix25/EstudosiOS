//
//  ComicList+Stubs.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 26/08/21.
//

import Foundation

@testable import TheAvengersInitiative

extension ComicList {
	static func stub() -> ComicList {
		let comicList: ComicList = .init(available: 10, items: [Comic.stub()])
		return comicList
	}
}
