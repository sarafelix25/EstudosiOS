//
//  Comic+Stubs.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 26/08/21.
//

import Foundation

@testable import TheAvengersInitiative

extension Comic {
	static func stub() -> Comic {
		let items: Comic = .init(title: "Abyss edition #001")
		return items
	}
}
