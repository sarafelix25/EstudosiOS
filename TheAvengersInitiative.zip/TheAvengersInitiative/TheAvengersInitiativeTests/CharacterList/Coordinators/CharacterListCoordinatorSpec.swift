//
//  CharacterListCoordinatorSpec.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 01/09/21.
//

import Foundation
import Quick
import Nimble

@testable import TheAvengersInitiative

final class CharacterListCoordinatorSpec: QuickSpec {
	override func spec() {
		
		var sut: CharacterListCoordinator!
		var window: UIWindow!
		
		describe("CharacterListCooordinator"){
			context("when start function is called"){
				
				beforeEach {
					window = .init(frame: .zero)
					sut = CharacterListCoordinator(window: window)
					sut.start()
				}
				
				it("should return expected CharactersListViewController"){
					let navigationController: UINavigationController = window.rootViewController as! UINavigationController
					expect(window.rootViewController).to(beAKindOf(UINavigationController.self))
					expect(navigationController.viewControllers.first).to(beAKindOf(CharactersListViewController.self))
				}
			}
			
			context("when didSelectCharacter function is called"){
				
				beforeEach {
					window = .init(frame: .zero)
					sut = CharacterListCoordinator(window: window)
					sut.start()
					sut.didSelectCharacter(Character.stub())
				}
				
				it("should return expected CharacterDetailViewController"){
					let navigationController: UINavigationController = window.rootViewController as! UINavigationController
					expect(navigationController.viewControllers.last).toEventually(beAKindOf(CharacterDetailViewController.self))
				}
			}
			
		}
	}
}
