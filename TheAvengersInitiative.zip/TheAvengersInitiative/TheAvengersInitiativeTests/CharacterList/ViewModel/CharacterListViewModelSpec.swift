//
//  CharacterListViewModelTesting.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 24/08/21.
//

import Foundation
import Quick
import Nimble

@testable import TheAvengersInitiative

final class CharacterListViewModelSpec: QuickSpec{
	override func spec() {
		
		var sut: CharacterListViewModel!
		
		let character: Character = .stub()
		let characteres: [Character] = [character]
		var apiSpy: CharactersAPISpy!
		var apiMock: CharactersApiMock!
		
		describe("CharacterListViewModel"){
			context("when name function is called"){
				
				beforeEach {
					apiSpy = CharactersAPISpy()
					sut = .init(characteres: characteres, api: apiSpy)
				}
				
				it("should return expected name"){
					expect(sut.name(at: 0)) == "Iron Man"
				}
			}
			
			context("when comicsCount function is called"){
				
				beforeEach {
					apiSpy = CharactersAPISpy()
					sut = .init(characteres: characteres, api: apiSpy)
				}
				
				it("should return expected comicsCount"){
					expect(sut.comicsCount(at: 0)) == 10
				}
			}
			
			//MARK: - func avatarURL

			context ( "when avatarURL function is called" ) {
				beforeEach {
					apiSpy = CharactersAPISpy()
					sut = CharacterListViewModel(characteres: characteres, api: apiSpy)
				}
				it ( "should return expected avatarURL" ) {
					expect(sut.avatarUrl(at: 0)) == (URL(string: "https://www.google.com.br/.PNG"))
				}
			}
			
			context ( "when requestCharacters function is called" ) {
				beforeEach {
					apiSpy = CharactersAPISpy()
					sut = CharacterListViewModel(characteres: characteres, api: apiSpy)
					sut.requestCharacters { }
				}
				it ( "should return expected api requestCharacters" ) {
					expect(apiSpy.didCallGetCharacters) == true
				}
			}
			
			context ( "when requestCharacters function is called" ) {
				beforeEach {
					apiSpy = CharactersAPISpy()
					sut = CharacterListViewModel(characteres: characteres, api: apiSpy)
				}
				it ( "should return expected api requestCharacters" ) {
					expect(sut.numberOfRows) == 1
				}
			}
			context("when requestCharacters is called with an mock"){
				
				context("when return sucess"){
					beforeEach {
						apiMock = CharactersApiMock()
						sut = CharacterListViewModel(api: apiMock)
						apiMock.shouldSucceed = true
						sut.requestCharacters { }
					}
					
					it("should return expected sucess"){
						expect(sut.characteres.count) == 10
					}
				}
				
				context("when return error"){
					beforeEach {
						apiMock = CharactersApiMock()
						sut = CharacterListViewModel(api: apiMock)
						apiMock.shouldSucceed = false
						sut.requestCharacters { }
					}
					
					it("should return expected error"){
						expect(sut.characteres.count) == 0
					}
				}
			}
		}
	}
}
