//
//  CharacterDetailViewModelSpec.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 25/08/21.
//

import Foundation
import Quick
import Nimble

@testable import TheAvengersInitiative

final class CharacterDetailViewModelSpec: QuickSpec {
	override func spec() {
		
		var sut: CharacterDetailViewModel!
		let character: Character = .stub(name: "Abyss")
		
		// MARK: - func name
		describe("CharacterDetailViewModel"){
			context ( "when name function is called" ) {
				beforeEach {
					sut = CharacterDetailViewModel(character: character)
				}
				it ( "should return expected name" ) {
					expect(sut.name()) == "Abyss"
				}
			}
		}
		// MARK: - func comicsID
		describe("CharacterDetailViewModel"){
			context ( "when comicsID function is called" ) {
				beforeEach {
					sut = CharacterDetailViewModel(character: character)
				}
				it ( "should return expected comicsID" ) {
					expect(sut.comicsID()) == "\(1)"
				}
			}
			//MARK: - func avatarURL
			context ( "when avatarURL function is called" ) {
				beforeEach {
					sut = CharacterDetailViewModel(character: character)
				}
				it ( "should return expected avatarURL" ) {
					expect(sut.avatarUrl()) == URL(string: "https://www.google.com.br/.PNG")
				}
			}
			//MARK: - func comicTitle
			context ( "when comicTitle function is called" ) {
				beforeEach {
					sut = CharacterDetailViewModel(character: character)
				}
				it ( "should return expected comicTitle" ) {
					expect(sut.comicTitle(at: 0)) == "Abyss edition #001"
				}
			}
			
			context ( "when requestCharacters function is called" ) {
				beforeEach {
					sut = CharacterDetailViewModel(character: character)
				}
				it ( "should return expected api requestCharacters" ) {
					expect(sut.numberOfRows) == 1
				}
			}
		}
	}
}
