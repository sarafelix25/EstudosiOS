//
//  CharacterDetailViewSpec.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 03/09/21.
//

import Foundation
import Quick
import Nimble_Snapshots
import Nimble

@testable import TheAvengersInitiative

final class CharacterDetailViewSpec: QuickSpec{
	override func spec() {
		
		var viewModel: CharacterDetailViewModel!
		var sut: CharacterDetailView!
		
		describe("CharacterDetailView"){
			context("when view is initialized"){
				
				beforeEach {
					viewModel = .init(character: Character.stub())
					sut = .init(detailvm: viewModel)
					sut.frame = UIScreen.main.bounds
				}
				
				it("should have expected layout"){
					expect(sut) == snapshot("CharacterDetail_View!")
				}
			}
		}
	}
}
