//
//  APIError.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 31/08/21.
//

import Foundation

enum APIError: Error {
	case generic
}
