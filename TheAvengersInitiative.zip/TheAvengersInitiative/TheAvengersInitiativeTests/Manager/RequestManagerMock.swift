//
//  RequestManagerMock.swift
//  TheAvengersInitiativeTests
//
//  Created by Matheus Mendes Peres on 25/08/21.
//

import Foundation

@testable import TheAvengersInitiative

final class requestManagerMock {
	
}
