//
//  APIHelper.swift
//  TheAvengersInitiative
//
//  Created by Felippe Bertges on 24/06/21.
//

import Foundation

final class APIHelper {
    static let marvelAPIKey: String = "71180e0d0ca397ea99017cb485cb232d"
    static let marvelPrivateAPIKey: String = "22b622474ef09b620e6458be842b0bd9fa0cb11d"
}
