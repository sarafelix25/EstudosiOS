//
//  Coordinator.swift
//  TheAvengersInitiative
//
//  Created by Felippe Bertges on 10/06/21.
//

import Foundation

protocol Coordinator {
    func start()
}
