# TheAvengersInitiative

Projeto criado para o treinamento dos estagiários da empresa. 
Existe também um keynote com o roadmap, explicações e referências.

## Como acompanhar as aulas

Cada <i>commit</i> é denominado pelo capítulo e tema. Ex: 01 Tipos e Operadores

Cada <i>tag</i> representa uma aula, podendo conter exercícios ou não. A numeração das tags é sequencial e independente do capítulo.
Tags com "R" no final representam as resoluções de exercícios da tag de mesmo número. Ex: <b><i>#002R</i></b> contém as respostas dos exercícios propostos em <b><i>#002</i></b>.

