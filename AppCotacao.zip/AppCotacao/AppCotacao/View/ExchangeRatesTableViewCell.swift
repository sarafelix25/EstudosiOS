//
//  ExchangeRateTableViewCell.swift
//  AppCotacao
//
//  Created by Sara on 13/12/21.
//

import UIKit

class ExchangeRatesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var rateValue: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
