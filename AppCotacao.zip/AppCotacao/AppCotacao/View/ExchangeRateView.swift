//
//  ExchangeRateView.swift
//  AppCotacao
//
//  Created by Sara on 13/12/21.
//

import UIKit

class ExchangeRateView: UIView {
    let viewController = ExchangeRateViewController()
}
