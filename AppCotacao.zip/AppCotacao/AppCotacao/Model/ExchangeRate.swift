//
//  ExchangeRate.swift
//  AppCotacao
//
//  Created by Sara on 13/12/21.
//

import Foundation

struct ExchangeRate: Decodable {
    let success: Bool?
    let timestamp: Date?
    let base: String?
    let date: String?
    let rates: [String: Double]?
}
